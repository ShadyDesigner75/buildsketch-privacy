/* BuildSketch V4 Pro — Service Worker */
var CACHE='bs-v4-1';
self.addEventListener('install',function(e){
  e.waitUntil(caches.open(CACHE).then(function(c){
    return c.add('./index.html').catch(function(){});
  }));
  self.skipWaiting();
});
self.addEventListener('activate',function(e){
  e.waitUntil(caches.keys().then(function(keys){
    return Promise.all(keys.filter(function(k){return k!==CACHE;})
      .map(function(k){return caches.delete(k);}));
  }));
  self.clients.claim();
});
self.addEventListener('fetch',function(e){
  if(e.request.method!=='GET')return;
  e.respondWith(fetch(e.request).then(function(res){
    if(res&&res.status===200){
      var cl=res.clone();
      caches.open(CACHE).then(function(c){c.put(e.request,cl);});
    }
    return res;
  }).catch(function(){
    return caches.match(e.request)
      .then(function(c){return c||caches.match('./index.html');});
  }));
});
